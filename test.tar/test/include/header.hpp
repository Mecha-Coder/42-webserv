#ifndef HEADER_HPP
#define HEADER_HPP

#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <unistd.h>
#include <poll.h>
#include <csignal>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cerrno>
#include <string>
#include <vector>

#define PORT 8080
#define MAX_CLIENTS 1024       // Increased from 64
#define BUFFER_SIZE 4096
#define MAX_REQUEST_SIZE 16384  // 16KB max request buffer

extern volatile sig_atomic_t server_run;

typedef struct Client 
{
    int fd;
    std::string buffer;
} t_client;


int set_nonblocking(int const &fd);

#endif