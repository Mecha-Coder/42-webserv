#include "../include/header.hpp"

volatile sig_atomic_t server_run = 1;

void stopServer(int sig)
{server_run = 0;}

int main()
{
    signal(SIGINT, stopServer);
}


