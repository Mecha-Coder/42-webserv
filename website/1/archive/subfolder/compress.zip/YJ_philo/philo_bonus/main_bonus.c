/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_bonus.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yphang <yphang@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/25 15:47:25 by yphang            #+#    #+#             */
/*   Updated: 2025/03/06 18:15:00 by yphang           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo_bonus.h"

int	ft_check_digit(char *argv)
{
	int	i;

	i = 0;
	while (argv[i])
	{
		if ((argv[i] < '0' || argv[i] > '9'))
			return (0);
		i++;
	}
	return (1);
}

void	ft_input(t_program *program, char **argv)
{
	program->num_philos = ft_atoi(argv[1]);
	program->die_time = ft_atoi(argv[2]);
	program->eat_time = ft_atoi(argv[3]);
	program->sleep_time = ft_atoi(argv[4]);
	program->num_eat = -1;
	if (argv[5])
		program->num_eat = ft_atoi(argv[5]);
}

int	main(int argc, char **argv)
{
	int			i;
	t_program	*program;
	// sem_unlink(WRITE_SEM_NAME);
	// sem_unlink(DIE_SEM_NAME);
	// sem_unlink(FORKS_SEM_NAME);
	// sem_unlink(MEAL_SEM_NAME);
	// sem_unlink(DEAD_FLAG_NAME);
	i = 1;
	if (argc != 5 && argc != 6)
		return (printf("Error: Incorrect number of arguments\n"), 1);
	while (argv[i])
	{
		if (!ft_check_digit(argv[i]) || ft_atoi(argv[i]) < 0)
			return (printf("Error: Invalid input\n"), 1);
		i++;
	}
	program = malloc(sizeof(t_program));
	if (!program)
		return (printf("Error: Memory allocation failed\n"), 1);
	ft_input(program, argv);
	if (ft_init(program))
		return (1);
	if (ft_init_philo(program))
		return (1);
	if (ft_philo(program))
		return (1);
	ft_destroy(program);
}
