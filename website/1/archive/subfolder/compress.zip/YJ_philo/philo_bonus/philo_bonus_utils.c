/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_bonus_utils.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yphang <yphang@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/25 15:51:10 by yphang            #+#    #+#             */
/*   Updated: 2025/03/06 15:54:52 by yphang           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo_bonus.h"

int	ft_get_time(void)
{
	struct timeval	tv;

	if (gettimeofday(&tv, NULL) == -1)
	{
		printf("Error: Fail to get time\n");
		return (0);
	}
	return ((tv.tv_sec * 1000) + (tv.tv_usec / 1000));
}

void	ft_usleep(int time_limit)
{
	int	time_start;

	time_start = ft_get_time();
	while (ft_get_time() - time_start < time_limit)
		usleep(100);
}

int	ft_strncmp(const char *s1, const char *s2, size_t n)
{
	if (n == 0)
		return (0);
	while (n--)
	{
		if (*s1 != *s2)
			return ((unsigned char)*s1 - (unsigned char)*s2);
		else if (!*s1 && !*s2)
			return (0);
		s1++;
		s2++;
	}
	return (0);
}

void	ft_print(t_program *program, int n_philo, char *msg)
{
	if (ft_strncmp(msg, "died", 4) == 0)
	{
		sem_wait(program->dead_flag_sem);
		sem_wait(program->write_sem);
		printf("%d %d %s\n", ft_get_time() - program->start_time, n_philo, msg);
		sem_post(program->write_sem);
		return ;
	}
	sem_wait(program->write_sem);
	printf("%d %d %s\n", ft_get_time() - program->start_time, n_philo, msg);
	sem_post(program->write_sem);
}
