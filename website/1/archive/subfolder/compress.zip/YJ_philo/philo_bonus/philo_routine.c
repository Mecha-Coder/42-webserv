/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_routine.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpaul <jpaul@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/25 18:44:59 by yphang            #+#    #+#             */
/*   Updated: 2025/03/07 11:27:36 by jpaul            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo_bonus.h"

void	lonely_philo(t_philo *philo)
{
	ft_print(philo->program, philo->id, "has taken a fork");
	ft_usleep(philo->program->die_time);
	is_dead(philo);
	ft_close_sem(philo->program);
	exit(1);
}

void	ft_eat(t_program *program, t_philo *philo)
{
	sem_wait(program->forks_sem);
	ft_print(philo->program, philo->id, "has taken a fork");
	sem_wait(program->forks_sem);
	ft_print(philo->program, philo->id, "has taken a fork");
	sem_wait(philo->eat_sem);
	philo->last_eat = ft_get_time();
	ft_print(program, philo->id, "is eating");
	philo->num_eaten++;
	if (philo->num_eaten >= philo->program->num_eat)
	{
		if (philo->full == 0)
		{
			philo->full = 1;
			sem_post(program->meal_sem);
		}
	}
	sem_post(philo->eat_sem);
	ft_usleep(philo->program->eat_time);
	sem_post(program->forks_sem);
	sem_post(program->forks_sem);
}

void	ft_routine(t_program *program, t_philo *philo)
{
	pthread_create(&philo->monitor, NULL, ft_monitor, (void *)philo);
	pthread_detach(philo->monitor);
	if (program->num_philos == 1)
		lonely_philo(philo);
	if (philo->id % 2 == 0)
		usleep(1000);
	while (1)
	{
		ft_eat(program, philo);
		ft_print(philo->program, philo->id, "is sleeping");
		ft_usleep(philo->program->sleep_time);
		ft_print(philo->program, philo->id, "is thinking");
	}
}

void	*is_full(void *arg)
{
	t_program	*program;
	int			meal;

	program = (t_program *)arg;
	meal = 0;
	while (1)
	{
		sem_wait(program->meal_sem);
		meal++;
		if (meal == program->num_philos)
			break ;
	}
	return (NULL);
}

int	ft_philo(t_program *program)
{
	int			i;
	//int			skip_wait;
	//pthread_t	meal_monitor;
	int status;
	pid_t child;

	//skip_wait = 0;
	i = 0;
	while (i < program->num_philos)
	{
		child = fork();
		if (child == -1)
			return (printf("Error: Fork process failed"), 1);
		if (child == 0)
			ft_routine(program, &program->philos[i]);
		else
			program->philos[i].pid = child;
		i++;
	}

	i = -1;
	while (++i < program->num_philos)
    {
        waitpid(-1, &status, 0);
        if (status != 0)
		{
			i = -1;
			while (++i < program->num_philos)
			{kill(program->philos[i].pid, SIGTERM);}
            break;
		}
    }

    i = -1;
    while (++i < program->num_philos)
    {waitpid(program->philos[i].pid, NULL, 0);}
	
	

	// if (program->num_eat > 0)
	// {
	// 	pthread_create(&meal_monitor, NULL, is_full, (void *)program);
	// 	pthread_join(meal_monitor, NULL);
	// 	skip_wait = 1;
	// }
	// if (!skip_wait)
	// 	waitpid(-1, NULL, 0);
	// ft_clean(program);
	return (0);
}
