/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_cleanup.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpaul <jpaul@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/05 15:29:58 by yphang            #+#    #+#             */
/*   Updated: 2025/03/07 10:50:52 by jpaul            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo_bonus.h"

void	ft_destroy(t_program *program)
{
	int	i;

	i = 0;
	sem_close(program->write_sem);
	sem_close(program->dead_sem);
	sem_close(program->forks_sem);
	sem_close(program->meal_sem);
	sem_close(program->dead_flag_sem);
	sem_unlink(WRITE_SEM_NAME);
	sem_unlink(DIE_SEM_NAME);
	sem_unlink(FORKS_SEM_NAME);
	sem_unlink(MEAL_SEM_NAME);
	sem_unlink(DEAD_FLAG_NAME);
	while (i < program->num_philos)
	{
		sem_close(program->philos[i].eat_sem);
		sem_unlink(program->philos[i].eat_sem_name);
		free(program->philos[i].eat_sem_name);
		i++;
	}
	free(program);
}

void	ft_close_sem(t_program *program)
{
	int	i;

	sem_close(program->write_sem);
	sem_close(program->dead_sem);
	sem_close(program->forks_sem);
	sem_close(program->meal_sem);
	sem_close(program->dead_flag_sem);
	i = 0;
	while (i < program->num_philos)
	{
		sem_close(program->philos[i].eat_sem);
		free(program->philos[i].eat_sem_name);
		i++;
	}
	free(program);
}

void	ft_clean(t_program *program)
{
	int	i;

	i = 0;
	while (i < program->num_philos)
	{
		kill(program->philos[i].pid, SIGKILL);
		i++;
	}
	sem_post(program->dead_flag_sem);
	i = 0;
	while (i < program->num_philos)
	{
		waitpid(-1, NULL, 0);
		i++;
	}
}
