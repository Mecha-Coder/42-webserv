/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_bonus.h                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yphang <yphang@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/25 15:33:49 by yphang            #+#    #+#             */
/*   Updated: 2025/03/06 15:09:49 by yphang           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILO_BONUS_H
# define PHILO_BONUS_H

# include <errno.h>
# include <fcntl.h>
# include <pthread.h>
# include <semaphore.h>
# include <signal.h>
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <sys/stat.h>
# include <sys/time.h>
# include <sys/wait.h>
# include <unistd.h>

# define MAX_PHILO 210

# define WRITE_SEM_NAME "/write_sem"
# define DIE_SEM_NAME "/die_sem"
# define FORKS_SEM_NAME "/forks_sem"
# define MEAL_SEM_NAME "/meal_sem"
# define DEAD_FLAG_NAME "/dead_flag_sem"

typedef struct s_program	t_program;

typedef struct s_philo
{
	int						id;
	int						last_eat;
	int						num_eaten;
	int						full;
	char					*eat_sem_name;

	pthread_t				monitor;
	pid_t					pid;
	sem_t					*eat_sem;
	t_program				*program;
}							t_philo;

struct						s_program
{
	t_philo					philos[MAX_PHILO];
	int						eat_time;
	int						die_time;
	int						sleep_time;

	int						num_eat;
	int						num_philos;
	int						start_time;

	sem_t					*dead_flag_sem;
	sem_t					*meal_sem;
	sem_t					*forks_sem;
	sem_t					*write_sem;
	sem_t					*dead_sem;
};

// main.c
void						ft_input(t_program *program, char **argv);
int							ft_check_digit(char *argv);

// initialise.c
int							ft_init(t_program *program);
int							ft_init_philo(t_program *program);

// philosophers.c
int							ft_philo(t_program *program);
int							ft_check_dead(t_philo *philo);
void						ft_routine(t_program *program, t_philo *philo);

// monitor.c
void						*ft_monitor(void *arg);
int							is_dead(t_philo *philo);
void						*is_full(void *arg);

// philo_utils.c
int							ft_get_time(void);
void						ft_print(t_program *program, int n_philo,
								char *msg);
void						ft_usleep(int time_limit);

// libft.c
int							ft_atoi(const char *str);
char						*ft_itoa(int n);
char						*ft_strjoin(const char *s1, const char *s2);

// philo_cleanup.c
void						ft_destroy(t_program *program);
void						ft_clean(t_program *program);
void						ft_close_sem(t_program *program);
#endif