/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   initialise_bonus.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yphang <yphang@student.42kl.edu.my>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/25 16:24:07 by yphang            #+#    #+#             */
/*   Updated: 2025/03/06 18:14:21 by yphang           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo_bonus.h"

int	ft_init(t_program *program)
{
	sem_unlink(WRITE_SEM_NAME);
	sem_unlink(DIE_SEM_NAME);
	sem_unlink(FORKS_SEM_NAME);
	sem_unlink(MEAL_SEM_NAME);
	sem_unlink(DEAD_FLAG_NAME);
	program->write_sem = sem_open(WRITE_SEM_NAME, O_CREAT | O_EXCL, 0644, 1);
	program->dead_sem = sem_open(DIE_SEM_NAME, O_CREAT | O_EXCL, 0644, 0);
	program->forks_sem = sem_open(FORKS_SEM_NAME, O_CREAT | O_EXCL, 0644,
			program->num_philos);
	program->meal_sem = sem_open(MEAL_SEM_NAME, O_CREAT | O_EXCL, 0644, 0);
	program->dead_flag_sem = sem_open(DEAD_FLAG_NAME, O_CREAT | O_EXCL, 0644,
			1);
	if (program->write_sem == SEM_FAILED)
		return (printf("Error: write_sem failed: %s\n", strerror(errno)), 1);
	if (program->dead_sem == SEM_FAILED)
		return (printf("Error: dead_sem failed\n"), 1);
	if (program->forks_sem == SEM_FAILED)
		return (printf("Error: forks_sem failed\n"), 1);
	if (program->meal_sem == SEM_FAILED)
		return (printf("Error: forks_lock failed\n"), 1);
	if (program->dead_flag_sem == SEM_FAILED)
		return (printf("Error: dead_flag_sem failed\n"), 1);
	return (0);
}

int	ft_init_philo(t_program *program)
{
	int		i;
	char	*id;

	i = 0;
	program->start_time = ft_get_time();
	while (i < program->num_philos)
	{
		id = ft_itoa(i + 1);
		program->philos[i].eat_sem_name = ft_strjoin("/eat_sem_", id);
		free(id);
		program->philos[i].id = i + 1;
		program->philos[i].last_eat = ft_get_time();
		program->philos[i].num_eaten = 0;
		program->philos[i].full = 0;
		program->philos[i].pid = -1;
		program->philos[i].program = program;
		sem_unlink(program->philos[i].eat_sem_name);
		program->philos[i].eat_sem = sem_open(program->philos[i].eat_sem_name,
				O_CREAT | O_EXCL, 0644, 1);
		if (program->philos[i].eat_sem == SEM_FAILED)
			return (printf("Error: write_sem failed: %s\n", strerror(errno)),
				1);
		i++;
	}
	return (0);
}
