/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   monitor_bonus.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jpaul <jpaul@student.42kl.edu.my>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/25 18:53:01 by yphang            #+#    #+#             */
/*   Updated: 2025/03/07 11:27:42 by jpaul            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo_bonus.h"

int	is_dead(t_philo *philo)
{
	int	last_eat;
	int	time_now;

	sem_wait(philo->eat_sem);
	last_eat = philo->last_eat;
	time_now = ft_get_time();
	sem_post(philo->eat_sem);
	if (time_now - last_eat >= philo->program->die_time)
	{
		ft_print(philo->program, philo->id, "died");
		return (1);
	}
	return (0);
}

void	*ft_monitor(void *arg)
{
	t_philo	*philo;

	philo = (t_philo *)arg;
	while (1)
	{
		if (is_dead(philo))
		{
			ft_close_sem(philo->program);
			exit(1);
		}
		ft_usleep(2);
	}
}
